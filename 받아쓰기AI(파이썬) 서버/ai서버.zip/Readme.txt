[ 파이썬 AI 모델 환경 설치 방법 ]
1. anaconda 설치 -> 파일 다운받아서 설치해야함
(anaconda 설치하면 python까지 한꺼번에 설치되기 때문에
기존에 설치된 python이랑 충돌 없으려면 anaconda 설치하기 전
python 지우는거 추천)

2. anaconda prompt -> 관리자 권한으로 실행

3. 가상환경 설정 (conda create -n 만들가상환경이름)

4. 가상환경 실행 (activate 만든가상환경이름)

5. 라이브러리 설치
(가상환경에서 설치하면 편함)
- tensorflow (pip install tensorflow) -> 2.6.0 설치됐음
- cv2 (pip install opencv-python)
- imageio (pip install imageio)

6. 실행시킬 파일이 있는 폴더 이동하고 anaconda 실행 창에서 (python 메인파일명.py)
이렇게 적으면 코드 실행된다.
(AI 모델 실행하려면 anaconda prompt에서 실행해야 함!!)

 - 만약 파이썬 서버 폴더가 D:\python_server 면
 - 콘솔 상에서 아래의 명령어를 입력하면 서버가 작동
 
 D:\python_server python webapp_TK.py

 * 폴더 내에 2개의 파이썬 파일이 있는데
   webapp_TK.py 파일이 서버 작동 파일이다 

7. 가상환경 종료할 때 (deactivate 현재가상환경이름)



saved_model : AI 학습결과 데이터가 저장된 폴더
image : C++ 서버에서 받은 이미지 저장하는 폴더